package com.example.persistence;

import com.example.domain.CEOVO;

public interface CEODAO {
	public CEOVO login(CEOVO vo) throws Exception;
}
