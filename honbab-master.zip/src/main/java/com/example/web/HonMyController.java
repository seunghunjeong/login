package com.example.web;

import java.io.FileInputStream;
import java.io.InputStream;

import javax.annotation.Resource;
import javax.inject.Inject;

import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.persistence.CEODAO;
import com.example.persistence.UserDAO;

@Controller
public class HonMyController {
	@Resource(name="uploadPath")
	private String path;
	@Inject
	UserDAO dao;
	@Inject
	CEODAO cdao;
	
	@RequestMapping("myPage")
	public String mMyPage() {
		return "main/mypage/myPage";
	}
	
	//�̹������� ���
	  @ResponseBody
	  @RequestMapping("/display")
	  public byte[] display(String fileName)throws Exception{
	    InputStream in=new FileInputStream(path + "/" + fileName);
	    byte[] image=IOUtils.toByteArray(in);
	    in.close();
	    return image;
	  }	
	
	@RequestMapping("userReview")
	public String mUserReview() {
		return "main/mypage/userReview";
	}
	
	@RequestMapping("bookMark")
	public String mBookMark() {
		return "main/mypage/bookMark";
	}
	
	@RequestMapping("pay")
	public String mPay() {
		return "main/mypage/pay";
	}
	
	@RequestMapping("userDrop")
	public String mUserDrop() {
		return "main/mypage/userDrop";
	}	
	
	@RequestMapping("ceoMyPage")
	public String mCeoMyPage() {
		return "main/mypage/ceoMyPage";
	}
	
	@RequestMapping("storeService")
	public String mStoreService() {
		return "main/mypage/storeService";
	}
	
	@RequestMapping("notice")
	public String mNotice() {
		return "main/mypage/notice";
	}
	
	@RequestMapping("customerCenter")
	public String mCustomerCenter() {
		return "main/mypage/customerCenter";
	}
	
	@RequestMapping("ceoDrop")
	public String mCeoDrop() {
		return "main/mypage/ceoDrop";
	}	
}
