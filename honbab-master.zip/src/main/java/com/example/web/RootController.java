package com.example.web;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.domain.CEOSVO;
import com.example.domain.CEOVO;
import com.example.domain.MenuVO;
import com.example.domain.UserVO;
import com.example.persistence.CEODAO;
import com.example.persistence.CEOSDAO;
import com.example.persistence.UserDAO;

@Controller
public class RootController {
	@Inject
	CEOSDAO csdao;
	
	@Inject
	CEODAO cdao;
	
	@Inject
	UserDAO udao;
	
	@RequestMapping("insertS")
	public String insertS(CEOSVO vo) throws Exception {
		return "main/roo/insertS";
	}	
	
	@RequestMapping(value="insertS", method=RequestMethod.POST)
	public String insertSPost(CEOSVO vo) throws Exception {
		csdao.insertS(vo);
		return "redirect:mainPage";
	}	
	
	@RequestMapping(value="deleteS", method=RequestMethod.POST)
	public @ResponseBody void delete(String sid) {
		try {
			csdao.deleteS(sid);
			
		}catch(Exception e) {
			System.out.println(e.toString());
		}
	}
	
	@RequestMapping("rpage")
	public String rpage(Model model, String sid) throws Exception {
		model.addAttribute("csvo", csdao.readS(sid));
		return "login/rpage";
	}
	
	@ResponseBody
	@RequestMapping("listS.json")
	public List<CEOSVO> listS() throws Exception {
		List<CEOSVO> list = csdao.listS();
		return list;
	}
	
	@ResponseBody
	@RequestMapping("listU.json")
	public List<UserVO> listU() throws Exception {
		List<UserVO> list = udao.listU();
		return list;
	}
	
	@RequestMapping(value="insertU", method=RequestMethod.POST)
	public String insertUPost(UserVO vo) throws Exception {
		udao.insertU(vo); 
		return "redirect:mainPage";
	}	
	
	@RequestMapping(value="deleteU", method=RequestMethod.POST)
	public @ResponseBody void deleteU(String uid) {
		try {
			udao.deleteU(uid);
			
		}catch(Exception e) {
			System.out.println(e.toString());
		}
	}
	
	@RequestMapping("menu")
	public String menu(Model model, String sid) throws Exception {
		model.addAttribute("mvo", cdao.readM(sid));
		return "main/read/RV/menu";
	}
	
	@ResponseBody
	@RequestMapping("listM.json")
	public List<MenuVO> listM() throws Exception {
		return cdao.listM();
	}

	@RequestMapping("insertM")
	public String insertM(MenuVO mvo) throws Exception {
		return "main/roo/insertM";
	}	
	@RequestMapping(value="insertM", method=RequestMethod.POST)
	public String insertMPost(MenuVO mvo) throws Exception {
		cdao.insertM(mvo);
		return "redirect:main/read/RV/menu";
	}	
	
	@RequestMapping(value="deleteM", method=RequestMethod.POST)
	public @ResponseBody void deleteM(String sid, int mcount) {
		try {
			cdao.deleteM(sid, mcount);
			
		}catch(Exception e) {
			System.out.println(e.toString());
		}
	}
}
