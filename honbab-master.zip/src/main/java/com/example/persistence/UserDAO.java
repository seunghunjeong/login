package com.example.persistence;

import java.util.List;

import com.example.domain.UserVO;

public interface UserDAO {
	public UserVO login(UserVO vo) throws Exception;
	public void insertU(UserVO vo) throws Exception;
	public void deleteU(String uid) throws Exception;
	public List<UserVO> listU() throws Exception;
	public UserVO readU(String uid) throws Exception;
}
