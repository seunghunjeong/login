package com.example.persistence;

import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.example.domain.CEOVO;
import com.example.domain.MenuVO;

@Repository
public class CEODAOImpl implements CEODAO{

	@Inject
	SqlSession session;
	String namespace="CEOMapper";
	
	@Override
	public CEOVO login(CEOVO vo) throws Exception {
		return session.selectOne(namespace + ".clogin", vo);
	}

	@Override
	public void insertM(MenuVO vo) throws Exception {
		session.insert(namespace + ".insertM", vo);
	}

	@Override
	public void deleteM(String sid, int mcount) throws Exception {
		HashMap<String, Object> map=new HashMap<String, Object>();
		map.put("sid", sid);
		map.put("mcount", mcount);
		session.delete(namespace + ".deleteM", map);
	}

	@Override
	public List<MenuVO> listM() throws Exception {
		return session.selectList(namespace + ".listM");
	}

	@Override
	public MenuVO readM(String sid) throws Exception {
		return session.selectOne(namespace + ".readM", sid);
	}

}
