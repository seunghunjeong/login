package com.example.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.example.domain.CEOSVO;

@Repository
public class CEOSDAOImpl implements CEOSDAO {
	@Inject
	SqlSession session;
	String namespace="RootMapper";
	
	@Override
	public void insertS(CEOSVO vo) {
		session.insert(namespace + ".insertS", vo);
	}

	@Override
	public void deleteS(String sid) throws Exception {
		session.delete(namespace + ".deleteS", sid);
	}

	@Override
	public List<CEOSVO> listS() throws Exception {
		return session.selectList(namespace + ".listS");
	}

	@Override
	public CEOSVO readS(String sid) throws Exception {
		return session.selectOne(namespace + ".readS", sid);
	}



}
