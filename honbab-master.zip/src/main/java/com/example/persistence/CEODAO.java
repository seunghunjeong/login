package com.example.persistence;

import java.util.List;

import com.example.domain.CEOVO;
import com.example.domain.MenuVO;

public interface CEODAO {
	public CEOVO login(CEOVO vo) throws Exception;
	
	//�����޴�
	public void insertM(MenuVO vo) throws Exception;
	public void deleteM(String sid, int mcount) throws Exception;
	public List<MenuVO> listM() throws Exception;
	public MenuVO readM(String sid) throws Exception;
	
}
