package com.example.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.example.domain.CEOVO;
import com.example.domain.UserVO;

@Repository	//500����
public class UserDAOImpl implements UserDAO{

	@Inject
	SqlSession session;
	String namespace="UserMapper";
	
	@Override
	public UserVO login(UserVO vo) throws Exception {
		return session.selectOne(namespace + ".login", vo);
	}

	@Override
	public void insertU(UserVO vo) throws Exception {
		session.insert(namespace + ".insertU", vo);
	}

	@Override
	public void deleteU(String uid) throws Exception {
		session.delete(namespace + ".deleteU", uid);
	}

	@Override
	public List<UserVO> listU() throws Exception {
		return session.selectList(namespace + ".listU");
	}

	@Override
	public UserVO readU(String uid) throws Exception {
		return session.selectOne(namespace + ".readU", uid);
	}


}
