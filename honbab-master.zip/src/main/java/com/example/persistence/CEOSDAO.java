package com.example.persistence;

import java.util.List;

import com.example.domain.CEOSVO;

public interface CEOSDAO {
	public void insertS(CEOSVO vo) throws Exception;
	public void deleteS(String sid) throws Exception;
	public List<CEOSVO> listS() throws Exception;
	public CEOSVO readS(String sid) throws Exception;
	
	
}
